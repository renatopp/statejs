YUI.add("yuidoc-meta", function(Y) {
   Y.YUIDoc = { meta: {
    "classes": [
        "Blackboard",
        "FSM",
        "State",
        "Subsumption",
        "Utility",
        "Utils"
    ],
    "modules": [
        "StateJS"
    ],
    "allModules": [
        {
            "displayName": "StateJS",
            "name": "StateJS",
            "description": "StateJS\n=======\n\n* * *\n\n**StateJS** is a Javascript library that provides state-based models such\nas Finite State Machines and the Subsumption architecture. It aims speed,\nlow memory consuption and multi-agent control. Check out some features \nof StateJS:\n\n- StateJS provides **Finite State Machines**, **Subsumption Architecture** \n  and **Utility Functions**;\n- **Extensible and Flexible**, create new Machines or your own version of \n  FSM or Utilities;\n- **Optimized to control multiple agents**, you can use a single machine \n  instance to handle hundreds of agents;\n- **Completely free**, StateJS is published under the MIT License, which \n  means that you can use it for your open source and commercial projects;\n- **Lightweight**, only 11.5KB!\n\nVisit http://statejs.guineashots.com to know more!"
        }
    ]
} };
});